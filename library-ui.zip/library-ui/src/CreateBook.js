import React, {Component} from 'react';
import './App.css';
import {connect} from "react-redux";
import {fetchBooksFromApi} from "./apis/fetchBooks";
import {storeBook} from "./apis/storeBook";

class CreateBook extends Component {
    constructor(props) {
        super(props);
        this.state = {
            name: '',
            preface: '',
            page_count: 0
        }

    }
    setInputValue = (e, inputName) => {
        this.setState({[inputName]: e.target.value})
    };

    submitForm = () => {
        const form = {name: this.state.name,
            preface: this.state.preface,
            page_count: this.state.page_count};

        storeBook(form)
    };


    render() {

        return (
            <div>
                <div>
                    <span>Name:  <input type='text' value={this.state.name} onChange={(e) => this.setInputValue(e, 'name')}/></span>
                </div>
                <div>
                    <span>Preface:  <input type='text' value={this.state.preface} onChange={(e) => this.setInputValue(e, 'preface')}/></span>
                </div>
                <div>
                    <span>Page Count:  <input type='number' value={this.state.page_count} onChange={(e) => this.setInputValue(e, 'page_count')}/></span>
                </div>
                <div>
                    <button onClick={this.submitForm}>Submit</button>
                </div>
            </div>
        );
    }
}

const mapStateToProps = (state) => {
    return {
        books: state.books,
    }
};

const mapDispatchToProps = (dispatch) => {
    return {
        fetchBooks: () => fetchBooksFromApi(dispatch)

    }
};

export default connect(mapStateToProps, mapDispatchToProps)(CreateBook)
