import {RECEIVE_BOOKS} from "../actions";

export const initialState = {
  books: []
};

export const rootReducer  = (state=initialState, action) => {
    switch (action.type) {
        case RECEIVE_BOOKS:
            return {...state, books: action.books};
        default:
            return state;
    }
};