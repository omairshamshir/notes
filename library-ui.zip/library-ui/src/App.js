import React, { Component } from 'react';
import './App.css';
import Welcome from "./welcome";

class App extends Component {
  render() {
    return (
        <div>
      <Welcome msg={"This is First Welcome"}/>

        </div>
    );
  }
}

export default App;
