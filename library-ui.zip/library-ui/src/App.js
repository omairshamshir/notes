import React, {Component} from 'react';
import './App.css';
import CreateBook from "./CreateBook";

class App extends Component {
    render() {
        return (
            <div>
                <CreateBook/>
            </div>
        );
    }
}

export default App;
