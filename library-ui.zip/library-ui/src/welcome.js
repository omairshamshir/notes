import React, { Component } from 'react';
import './App.css';
import WelcomeToggler from "./WelcomeChild";

class Welcome extends Component {
    constructor(props){
        super(props);
        this.state = {
            counter: 1,
            inputText: 'start',
            displayWelcomeNote: false,
        }
    }

    incrementCounter = () => {
        this.setState({counter: this.state.counter + 1})
    };

    incrementCounter = () => {
        this.setState({counter: this.state.counter + 1})
    };

    handleWelcomeToggle = () => {
        this.setState({displayWelcomeNote: !this.state.displayWelcomeNote})
    };


    render() {

        const initialText = 'hello';
        return (
            <div className="App">
                <WelcomeToggler toggleHandler={this.handleWelcomeToggle}/>
                {this.state.displayWelcomeNote && <div>{this.props.msg}</div>}
                <div>{this.state.inputText}</div>
                <input
                    type='text'
                    value={this.state.inputText}
                    onChange={() => this.handleInputChange(initialText)}

                    />

                <div>{this.state.counter}</div>

                <button onClick={this.incrementCounter}>Update State</button>
            </div>
        );
    }
}

export default Welcome;
