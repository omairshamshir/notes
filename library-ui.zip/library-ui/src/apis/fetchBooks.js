import {receive_books} from "../actions";

export const fetchBooksFromApi = (dispatch) => {
    fetch('http://127.0.0.1:8000/books/?format=json')
        .then(response => response.json())
        .then(jsonData => dispatch(receive_books(jsonData)));
};