

export const storeBook = (payload) => {
    fetch(`http://127.0.0.1:8000/books/`,
        {
            method: 'POST',
            body: JSON.stringify(payload),
            headers: {
                'Content-Type': 'application/json'
            }
        }
        )
        .then(response => response.json())
        // .catch(e => {})

};