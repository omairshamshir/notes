import React, {Component} from 'react';
import './App.css';
import {connect} from "react-redux";
import {fetchBooksFromApi} from "./apis/fetchBooks";

class Books extends Component {
    constructor(props) {
        super(props);
        this.state = {
            posts: []

        }
    }

    componentDidMount() {
        this.props.fetchBooks()

            }


    render() {

        return (
            <div>
                <ul>
                    {this.props.books.map(book => {
                        return <li>
                            <h3>{book.name}</h3>
                            <p>{book.preface}</p>

                        </li>
                    })}
                </ul>
            </div>
        );
    }
}

const mapStateToProps = (state) => {
    return {
        books: state.books,
    }
};

const mapDispatchToProps = (dispatch) => {
  return {
      fetchBooks: () => fetchBooksFromApi(dispatch)

  }
};

export default connect(mapStateToProps, mapDispatchToProps)(Books)
