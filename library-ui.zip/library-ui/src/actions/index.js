export const RECEIVE_BOOKS = 'RECEIVE_BOOKS';

export const receive_books = (books) => {
    return {
        type: RECEIVE_BOOKS,
        books: books
    }
};