import React, { Component } from 'react';
import './App.css';

class WelcomeToggler extends Component {
    constructor(props){
        super(props);

    }


    render() {
        return (
            <div className="App">
                <button onClick={this.props.toggleHandler}>Toggle Welcome</button>

            </div>
        );
    }
}

export default WelcomeToggler;
