from django.contrib.auth.base_user import BaseUserManager


class CustomUserManager(BaseUserManager):
    def _create_user(self, email, username, password):
        user = self.model(username=username, email=email)
        user.set_password(password)
        return user

    def create_user(self, email, username, password):
        user = self._create_user(email, username, password)
        user.save()

    def create_superuser(self, email, username, password):
        user = self._create_user(email, username, password)
        user.is_staff = True
        user.is_superuser = True
        user.save()

    def create_staffuser(self, email, username, password):
        user = self._create_user(email, username, password)
        user.is_staff = True
        user.is_superuser = False
        user.save()
