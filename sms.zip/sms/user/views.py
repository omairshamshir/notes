from django.http import HttpResponse, JsonResponse
from django.shortcuts import render
import json

# Create your views here.
from rest_framework.generics import ListAPIView, ListCreateAPIView, RetrieveUpdateDestroyAPIView
from rest_framework.response import Response

from user.models import Student
from user.serializers import StudentSerializer


class UserListView(ListCreateAPIView):
    serializer_class = StudentSerializer

    def get_queryset(self):
        students_queryset = Student.objects.all()
        roll_no_gt = self.request.GET.get('roll_no_gt')
        if roll_no_gt:
            students_queryset = students_queryset.filter(roll_number__gt=roll_no_gt)
        return students_queryset


class UserUpdateRetrieveDeleteView(RetrieveUpdateDestroyAPIView):
    serializer_class = StudentSerializer
    queryset = Student.objects.exclude(id=1)



def user_first_view(request):
    print(request.GET)
    students = Student.objects.all()
    roll_no_gt = request.GET.get('roll_no_gt')

    if roll_no_gt:
        students = students.filter(roll_number__gt=roll_no_gt)

    students_info = StudentSerializer(students, many=True).data
    return Response(students_info)


def create_user(request):
    data = request.body
    data = json.loads(data.decode('utf-8'))
    user = Student.objects.create(name=data['name'], roll_number=data['roll_number'], section=data['section'])
    return HttpResponse('User Created')


def retrieve_user(request, pk):
    student = Student.objects.get(id=pk)
    student_info = StudentSerializer(student).data
    return JsonResponse(student_info)

def update_user(request, pk):
    student = Student.objects.get(id=pk)
    data = request.body
    data = json.loads(data.decode('utf-8'))
    student.section = data.get('section')
    student.save()
    return JsonResponse({'success': True})
