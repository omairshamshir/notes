from django.http import HttpResponse, JsonResponse
from django.shortcuts import render
import json

# Create your views here.
from rest_framework.generics import ListAPIView, ListCreateAPIView, RetrieveUpdateDestroyAPIView
from rest_framework.response import Response
from rest_framework.views import APIView

from user.models import Student
from user.serializers import StudentSerializer


class UserListView(ListCreateAPIView):
    serializer_class = StudentSerializer

    def get_queryset(self):
        students_queryset = Student.objects.all()
        roll_no_gt = self.request.GET.get('roll_no_gt')
        if roll_no_gt:
            students_queryset = students_queryset.filter(roll_number__gt=roll_no_gt)
        return students_queryset


class UserUpdateRetrieveDeleteView(RetrieveUpdateDestroyAPIView):
    serializer_class = StudentSerializer
    queryset = Student.objects.all()


class CustomUserView(APIView):
    def get(self, request, *args, **kwargs):
        students = Student.objects.all()
        students_data = StudentSerializer(students, many=True)
        return Response(students_data.data)

    def post(self, request, *args, **kwargs):
        data = request.data
        serializer = StudentSerializer(data=data)
        if serializer.is_valid(raise_exception=True):
            serializer.save()
        return Response(serializer.data)


class CustomUserRetrieveView(APIView):
    def get(self, request, pk, *args, **kwargs):
        student = Student.objects.get(id=pk)
        students_data = StudentSerializer(student)
        return Response(students_data.data)
