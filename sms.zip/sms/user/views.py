from django.http import HttpResponse, JsonResponse
from django.shortcuts import render
import json

# Create your views here.
from user.models import Student


def user_first_view(request):
    print(request.GET)
    roll_no_gt = request.GET.get('roll_no_gt')

    students = Student.objects.filter(roll_number__gt=roll_no_gt)
    students_info = []
    for student in students:
        info = {
            'name': student.name,
            'roll_number': student.roll_number,
            'section': student.section
        }
        students_info.append(info)

    return HttpResponse(students_info)


def create_user(request):
    data = request.body
    data = json.loads(data.decode('utf-8'))
    user = Student.objects.create(name=data['name'], roll_number=data['roll_number'], section=data['section'])
    return HttpResponse('User Created')