from django.db import models


class Profile(models.Model):
    age = models.IntegerField()
    address = models.CharField(max_length=100, null=True, blank=True)
    year_of_education = models.IntegerField()



class Student(models.Model):
    name = models.CharField(max_length=120)
    roll_number = models.IntegerField(default=0)
    section = models.CharField(max_length=10, null=True, blank=True)
    profile = models.OneToOneField(Profile, null=True, blank=True, on_delete=models.CASCADE)

    def __str__(self):
        return str(self.roll_number)


class ResultCard(models.Model):
    marks = models.IntegerField()
    is_passed = models.BooleanField()
    student = models.ForeignKey(Student, on_delete=models.CASCADE, related_name='results')