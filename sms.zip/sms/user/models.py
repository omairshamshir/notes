from django.contrib.auth.base_user import AbstractBaseUser
from django.contrib.auth.models import PermissionsMixin, AbstractUser
from django.db import models
from django.utils import timezone

from courses.models import Course
from user.manager import CustomUserManager


class CustomUser(AbstractBaseUser, PermissionsMixin):
    username = models.CharField(max_length=120, unique=True)
    email = models.EmailField(unique=True, help_text='This is an email field')
    first_name = models.CharField(max_length=120, null=True, blank=True)
    last_name = models.CharField(max_length=120, null=True, blank=True)
    is_staff = models.BooleanField(default=False)
    is_superuser = models.BooleanField(default=False)
    date_joined = models.DateTimeField(default=timezone.now)
    is_active = models.BooleanField(default=True)


    objects = CustomUserManager()

    USERNAME_FIELD = 'username'
    EMAIL_FIELD = 'email'
    REQUIRED_FIELDS = ['email']





class Profile(models.Model):
    age = models.IntegerField()
    address = models.CharField(max_length=100, null=True, blank=True)
    year_of_education = models.IntegerField()



class Student(models.Model):
    name = models.CharField(max_length=120)
    roll_number = models.IntegerField(default=0)
    section = models.CharField(max_length=10, null=True, blank=True)
    profile = models.OneToOneField(Profile, null=True, blank=True, on_delete=models.CASCADE)
    courses = models.ManyToManyField(Course)

    def __str__(self):
        return str(self.roll_number)


class ResultCard(models.Model):
    marks = models.IntegerField()
    is_passed = models.BooleanField()
    student = models.ForeignKey(Student, on_delete=models.CASCADE, related_name='results')