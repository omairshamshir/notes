from rest_framework import serializers
from rest_framework.exceptions import ValidationError

from user.models import Student


class StudentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Student
        fields = '__all__'

    def validate(self, attrs):

        current_count = Student.objects.filter(section=attrs.get('section')).count()
        if current_count > 3:
            raise ValidationError('Exceeding limit of 30 students')
        return attrs

    def create(self, validated_data):
        courses = validated_data.pop('courses')
        student = Student.objects.create(**validated_data)
        student.courses.set(courses)
        return student

    def update(self, instance, validated_data):
        courses = validated_data.pop('courses', [])
        for param, value in validated_data.items():
            setattr(instance, param, value)
        instance.save()
        for course in courses:
            instance.courses.add(course)
        return instance
