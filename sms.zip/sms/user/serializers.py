from rest_framework import serializers
from rest_framework.exceptions import ValidationError

from user.models import Student


class StudentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Student
        fields = '__all__'

    def validate(self, attrs):

        current_count = Student.objects.filter(section=attrs.get('section')).count()
        if current_count > 3:
            raise ValidationError('Exceeding limit of 30 students')
        return attrs