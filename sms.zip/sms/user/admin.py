from django.contrib import admin

# Register your models here.
from django.contrib.auth.admin import UserAdmin

from user.models import Student, CustomUser


@admin.register(CustomUser)
class UserAdminTest(UserAdmin):
    list_display = ('id', 'email', 'username')

@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    list_display = ('id', 'roll_number', 'name')
    search_fields = ('name',)
    list_filter = ('section',)
