from django.contrib import admin

# Register your models here.


from user.models import Student


@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    list_display = ('id', 'roll_number', 'name')
    search_fields = ('name',)
    list_filter = ('section',)
