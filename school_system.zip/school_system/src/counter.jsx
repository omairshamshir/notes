import React from 'react';

class CounterComponent extends React.Component{
  constructor(props) {
    super(props);
    this.state = {
      counter: 0,
      finalCount: 0,
      firstInputValue: ''
    }
  }

  updateCounter = () => {
    this.setState({
      counter: this.state.counter + 1
    });
    this.props.parentUpdate();
  };

  componentDidMount() {
    console.log("Component Mounted")
  }

  componentDidUpdate(prevProps, prevState, snapshot) {
    console.log("Component Updated")
  }

  updateTextInput = (e) => {
    this.setState({
      firstInputValue: e.target.value
    })
  };


  render() {
    return <div>
      <div>{this.props.appName}</div>
      <input type='text' value={this.state.firstInputValue} onChange={this.updateTextInput}/>
      <div className='currentCount'>{`Current Count: ${this.state.counter}` }</div>
      <button onClick={this.updateCounter}>Counter</button>
    </div>
  }
}

export default CounterComponent;