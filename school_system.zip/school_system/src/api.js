import { addTodos } from './actions';

export const getTodos = (dispatch) => {
  fetch('http://127.0.0.1:8000/users/').then(
    response => response.json()
  ).then(json => dispatch(addTodos(json)))
};

export const addUser = (dispatch, data) => {
  fetch('http://127.0.0.1:8000/users/', {
    method: 'POST',
    body: JSON.stringify(data),
    headers: {
      'Content-Type': 'application/json'
    }
  }).then(
    response => response.json()
  ).then(json => console.log(json))
};