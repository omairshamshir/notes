import React from 'react';
import CounterComponent from './counter';
import { getTodos } from './api';
import { connect } from 'react-redux';

class TodoListComponent extends React.Component{
  constructor(props) {
    super(props);
  }

  componentDidMount() {
    this.props.getTodos();
  }


  render() {

    return <div>
      <ul>
      {
        this.props.todos.map(todo=><li>{todo.name}</li>)
      }
      </ul>
    </div>
  }
}

const mapStateToProps = (state) => ({
  todos: state.todos,
});

const mapDispatchToProps = (dispatch) => ({
  getTodos: () => getTodos(dispatch)
});

export default connect(mapStateToProps, mapDispatchToProps)(TodoListComponent);