import React from 'react';
import CounterComponent from './counter';

class TodoListComponent extends React.Component{
  constructor(props) {
    super(props);
    this.state = {
      todos: [],
    }
  }

  componentDidMount() {
    this.getTodos();
  }

  getTodos = () => {
    fetch('https://jsonplaceholder.typicode.com/todos').then(
      response => response.json()
    ).then(json => this.setState({
      todos: json
    }))
  };


  render() {

    return <div>
      <ul>
      {
        this.state.todos.map(todo=><li>{todo.title}</li>)
      }
      </ul>
    </div>
  }
}

export default TodoListComponent;