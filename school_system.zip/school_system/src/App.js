import React from 'react';
import './App.css';
import ParentCounterComponent from './parentCounter';
import TodoListComponent from './todoList';

function App() {
  return (
    <div className="App">
      <h1>First app</h1>
      <TodoListComponent/>
    </div>
  );
}

export default App;
