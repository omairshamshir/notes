import React from 'react';
import './App.css';
import ParentCounterComponent from './parentCounter';
import TodoListComponent from './todoList';
import { Route, Switch } from 'react-router-dom';
import AddStudentComponent from './addUser';

function App() {
  return (
    <Switch>
      <Route path={'/todos'} component={TodoListComponent}/>
      <Route path={'/counter'} component={ParentCounterComponent}/>
      <Route path={'/add'} component={AddStudentComponent}/>
    </Switch>
  );
}

export default App;
