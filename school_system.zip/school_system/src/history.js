import { createBrowserHistory } from 'history';

const HISTORY = createBrowserHistory();

export default HISTORY;