export const addTodos = (data) => {
  return {
    type: 'ADD_TODOS',
    data
  }
};