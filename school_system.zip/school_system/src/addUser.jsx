import React from 'react';
import CounterComponent from './counter';
import { addUser, getTodos } from './api';
import { connect } from 'react-redux';

class AddStudentComponent extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      'name': '',
      'roll_number': ''
    }
  }

  onChange = (e) => {
    this.setState({
      [e.target.name]: e.target.value
    })
  };

  onSubmit = () => {
    const payload = {...this.state};
    this.props.addUserProp(payload);
  };

  componentDidMount() {
    // this.props.getTodos();
  }


  render() {

    return <div>
      <h3>Add User</h3>
      <div>
        <span>Name</span>
        <input type={'text'} name={'name'} value={this.state.name} onChange={this.onChange} />
      </div>
      <div>
        <span>Roll Number</span>
        <input type={'number'}
               name={'roll_number'}
               value={this.state.roll_number}
               onChange={this.onChange} />
      </div>
      <button onClick={this.onSubmit} >Submit</button>
    </div>
  }
}

const mapStateToProps = (state) => ({});

const mapDispatchToProps = (dispatch) => ({
  addUserProp: (data) => addUser(dispatch, data)
});

export default connect(mapStateToProps, mapDispatchToProps)(AddStudentComponent);