export const INITIAL_STATE = {
  todos: [],
};

export const rootReducer = (state=INITIAL_STATE, action) => {
  switch (action.type) {
    case 'ADD_TODOS':
      return {
        ...state,
        todos: action.data
      };
    default:
      return state
  }
};