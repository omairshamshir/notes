import React from 'react';
import CounterComponent from './counter';

class ParentCounterComponent extends React.Component{
  constructor(props) {
    super(props);
    this.state = {
      totalCounter: 0,
    }
  }

  updateTotalCounter = () => {
    this.setState({
      totalCounter: this.state.totalCounter + 1
    })
  };


  render() {
    return <div>
      <div className='currentCount'>{`Total Count: ${this.state.totalCounter}` }</div>
      <CounterComponent appName={'First Counter'} parentUpdate={this.updateTotalCounter}/>
      <CounterComponent appName={'Second Counter'} parentUpdate={this.updateTotalCounter}/>
      <CounterComponent appName={'Third Counter'} parentUpdate={this.updateTotalCounter}/>
    </div>
  }
}

export default ParentCounterComponent;