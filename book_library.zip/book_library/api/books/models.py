from django.db import models


class Recommendation(models.Model):
    title = models.CharField(max_length=200)
    description = models.TextField()
    rating = models.FloatField()


class Tags(models.Model):
    name = models.CharField(max_length=100)


class Book(models.Model):
    name = models.CharField(max_length=200, db_index=True)
    page_count = models.IntegerField()
    published_on = models.DateField('publish date')
    recommendation = models.OneToOneField(Recommendation, on_delete=models.CASCADE,
                                          blank=True, null=True)
    tags = models.ManyToManyField(Tags)

    def __str__(self):
        return self.name

    class Meta:
        ordering = ['published_on']

    def get_depth(self):
        if self.page_count > 2:
            return 'heavy'

class Chapter(models.Model):
    book = models.ForeignKey(Book, related_name='chapters', on_delete=models.CASCADE)
    title = models.CharField(max_length=100)
    number = models.IntegerField()
