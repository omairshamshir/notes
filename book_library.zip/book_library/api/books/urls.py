from django.urls import path, re_path

from api.books.views import books_welcome, books_welcome_two

urlpatterns = [
    re_path('(?P<id>[0-9]+)', books_welcome, name='welcome'),
    re_path('welcome/(?P<pages>[0-9]+)', books_welcome_two, name='welcome')
]
