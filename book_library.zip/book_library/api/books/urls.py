from django.urls import path, re_path

from api.books.views import books_welcome, books_welcome_two, BookList, BookDetail

urlpatterns = [
    re_path('books/$', BookList.as_view(), name='book_list'),
    path('books/<int:pk>', BookDetail.as_view(), name='book_list'),
    re_path('welcome/(?P<pages>[0-9]+)', books_welcome_two, name='welcome')
]
