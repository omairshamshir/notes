from django.urls import path

from api.books.views import books_welcome

urlpatterns = [
    path('welcome', books_welcome, name='welcome')
]
