from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
from django.http import JsonResponse
from rest_framework import permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView

from .models import Book
from .serializers import BookSerializer, ChapterSerializer


class BookList(APIView):
    permission_classes = (permissions.AllowAny,)

    def get(self, request, format=None):
        return Response([BookSerializer(book).data for book in Book.objects.all()])

    def post(self, request):
        payload = request.data
        chapters = payload.pop('chapters', [])
        book_serializer = BookSerializer(data=payload)
        if book_serializer.is_valid(raise_exception=True):
            saved_book = book_serializer.save()
            for chapter in chapters:
                chapter['book'] = saved_book.id
                chapter_serializer = ChapterSerializer(data=chapter)
                if chapter_serializer.is_valid(raise_exception=True):
                    chapter_serializer.save()

        return Response(book_serializer.data, status=status.HTTP_201_CREATED)


class BookDetail(APIView):
    permission_classes = (permissions.AllowAny,)

    def get(self, request, pk):
        book = Book.objects.get(id=pk)
        serializer = BookSerializer(book)
        return Response(serializer.data)

    def put(self, request, pk):
        payload = request.data
        book = Book.objects.get(id=pk)
        serializer = BookSerializer(book, data=payload, partial=True)
        if serializer.is_valid(raise_exception=True):
            serializer.save()
        return Response(serializer.data)


@login_required
def books_welcome(request, id):
    b = Book.objects.get(id=id)
    return JsonResponse({'name': b.name, 'page_count': b.page_count, 'user': request.user.email,
                         'is_auth': request.user.is_authenticated})


def books_welcome_two(request, pages):
    return HttpResponse("<h3>Hello {}</h3>".format(request.user.email))
