from django.http import HttpResponse


# Create your views here.
def books_welcome(request):
    return HttpResponse("<h3>Hello</h3>")
