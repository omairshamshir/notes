from django.http import HttpResponse
from django.http import JsonResponse

# Create your views here.
from api.books.models import Book


def books_welcome(request, id):
    b = Book.objects.get(id=id)
    return JsonResponse({'name': b.name, 'page_count': b.page_count})


def books_welcome_two(request, pages):
    return HttpResponse("<h3>Hello {}</h3>".format(pages))
