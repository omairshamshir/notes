from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
from django.http import JsonResponse

# Create your views here.
from api.books.models import Book

@login_required
def books_welcome(request, id):
    b = Book.objects.get(id=id)
    return JsonResponse({'name': b.name, 'page_count': b.page_count, 'user':request.user.email, 'is_auth': request.user.is_authenticated})


def books_welcome_two(request, pages):
    return HttpResponse("<h3>Hello {}</h3>".format(request.user.email))
