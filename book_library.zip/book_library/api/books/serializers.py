from rest_framework import serializers
from rest_framework.exceptions import ValidationError

from .models import Book, Chapter, Tags


class TagSerializer(serializers.ModelSerializer):
    class Meta:
        model = Tags
        fields = '__all__'


class ChapterSerializer(serializers.ModelSerializer):
    class Meta:
        model = Chapter
        fields = '__all__'

    def create(self, validated_data):
        book = validated_data.pop('book')
        return Chapter.objects.create(book=book, **validated_data)



class BookSerializer(serializers.ModelSerializer):
    chapters = ChapterSerializer(many=True, required=False)
    tags = TagSerializer(many=True, required=False)

    class Meta:
        model = Book
        fields = '__all__'

    def create(self, validated_data):
        book = Book.objects.create(**validated_data)
        return book

    def validate(self, attrs):
        if not attrs.get('page_count') or attrs.get('page_count') < 10:
            raise ValidationError("Book is too small to read")
        return attrs

    def update(self, instance, validated_data):
        for k, v in validated_data.items():
            setattr(instance, k, v)
        instance.save()
        return instance
