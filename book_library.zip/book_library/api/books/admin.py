from django.contrib import admin

# Register your models here.
from api.books.models import Book


class BookAdmin(admin.ModelAdmin):
    list_display = ('name', 'page_count')
    list_display_links = ('name', 'page_count')
    list_filter = ('tags__name',)


admin.site.register(Book, BookAdmin)
