from django.contrib import admin

# Register your models here.
from django.contrib.auth.admin import UserAdmin

from api.user_management.models import LibraryUser


class LibraryUserAdmin(UserAdmin):
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('email', 'username', 'password1', 'password2'),
        }),
    )


admin.site.register(LibraryUser, LibraryUserAdmin)
