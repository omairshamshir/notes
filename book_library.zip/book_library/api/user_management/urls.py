from django.urls import path, re_path

from api.user_management.views import login_view

urlpatterns = [
    re_path('login', login_view, name='login'),
]
