from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponse


def login_view(request):
    email = request.POST['email']
    password = request.POST['password']
    user = authenticate(request, email=email, password=password)
    if user is not None:
        login(request, user)
        return HttpResponse("Successful Login")
    else:
        return HttpResponse("UnSuccessful Login")


def logout_view(request):
    logout(request)
