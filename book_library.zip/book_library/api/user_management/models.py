from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin
from django.db import models

from api.user_management.manager import LibraryUserManager


class LibraryUser(AbstractBaseUser, PermissionsMixin):
    """
    Model to store and authenticate cresta
    users, it will be created with the info
    that user provides for login into a
    particular chat service
    """

    # defining the custom objects manager

    objects = LibraryUserManager()

    username = models.CharField(
        unique=True,
        max_length=255,
    )
    email = models.EmailField(
        verbose_name='email address',
        max_length=255,
        unique=True,
    )

    first_name = models.CharField(max_length=30, blank=True)
    last_name = models.CharField(max_length=30, blank=True)

    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)

    date_joined = models.DateTimeField(null=True, blank=True)

    created_at = models.DateTimeField(auto_now_add=True)
    modified_at = models.DateTimeField(auto_now=True)

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = []  # Email & Password are required by default.

    def get_full_name(self):
        """
        Returns the first_name plus the last_name, with a space in between.
        """
        full_name = '%s %s' % (self.first_name, self.last_name)
        return full_name.strip()

    def get_short_name(self):
        "Returns the short name for the user."
        return self.first_name

    def __str__(self):  # __unicode__ on Python 2
        return self.email
